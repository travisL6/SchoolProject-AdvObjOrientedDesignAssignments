#include <iostream>
#include "Date.h"
#include <cassert>
using namespace std;

string monthName[] = { "January", "February", "March",
		"April", "May", "June", "July",
		"August", "September", "October",
		"November", "December" };

Date::Date(int month, int day, int year, int hrs, int min)
{
	if (month > 12 || month < 1)
	{
		cout << "The month is invalid.";
		assert(false);
	}
	else this->month = month;

	if (day > 31 || day < 1)
	{
		cout << "The day is invalid.";
		assert(false);
	}
	else this->day = day;

	this->year = year;

	if (hrs > 23 || hrs < 0)
	{
		cout << "The amount of hours is invalid.";
		assert(false);
	}
	else this->hours = hrs;

	if (min > 59 || min < 0)
	{
		cout << "The amount of minutes is invalid.";
		assert(false);
	}
	else this->minutes = min;
}

Date:: ~Date()
{
}

int Date::get_month() const
{
	return this->month;
}

int Date::get_day() const
{
	return this->day;
}

int Date::get_year() const
{
	return this->year;
}

int Date::get_hours() const
{
	return this->hours;
}

int Date::get_minutes() const
{
	return this->minutes;
}

void Date::printDate1(int numFutureDays)
{
	int newDay = get_day() + numFutureDays;
	int newMonth = get_month();
	int newYear = get_year();
	if (newDay > 31)
	{
		newDay = newDay - 31;
		if (newMonth == 12)
		{
			newMonth = 1;
			newYear++;
		}
		else newMonth++;
	}
	if (minutes < 10)
	{
		cout << newMonth << "/" << newDay << "/" << newYear << " " << get_hours() << ":0" << get_minutes() << endl;
	}
	else cout << newMonth << "/" << newDay << "/" << newYear << " " << get_hours() << ":" << get_minutes() << endl;
	
}

void Date::printDate2(int numFutureDays)
{
	int newDay = get_day() + numFutureDays;
	int newMonth = get_month();
	int newYear = get_year();
	int newHour = get_hours();
	if (newDay > 31)
	{
		newDay = newDay - 31;
		if (newMonth == 12)
		{
			newMonth = 1;
			newYear++;
		}
		else newMonth++;
	}
	string abrev;
	if (get_hours() >= 12)
	{
		abrev = " PM";
		newHour = get_hours() - 12;
	}
	else abrev = " AM";

	if (minutes < 10)
	{
		cout << monthName[newMonth - 1] << " " << newDay << ", " << newYear << " " << newHour << ":0" << get_minutes() << abrev << endl;
	}
	else cout << monthName[newMonth - 1] << " " << newDay << ", " << newYear << " " << newHour << ":" << get_minutes() << abrev << endl;

	
}

void Date::printDate3(int numFutureDays)
{
	int newDay = get_day() + numFutureDays;
	int newMonth = get_month();
	int newYear = get_year();
	int newHour = get_hours();
	if (newDay > 31)
	{
		newDay = newDay - 31;
		if (newMonth == 12)
		{
			newMonth = 1;
			newYear++;
		}
		else newMonth++;
	}
	string abrev;
	if (get_hours() >= 12)
	{
		abrev = " PM";
		newHour = get_hours() - 12;
	}
	else abrev = " AM";

	if (minutes < 10)
	{
		cout << newDay << " " << monthName[newMonth - 1] << " " << newYear << " " << newHour << ":0" << get_minutes() << abrev << endl;
	}
	else cout << newDay << " " << monthName[newMonth - 1] << " " << newYear << " " << newHour<< ":" << get_minutes() << abrev << endl;
}