#ifndef Date_H
#define Date_H
class Date
{
private:
	int month;
	int day;
	int year;
	int hours;
	int minutes;
public:
	Date(int month, int day, int year, int hours, int minutes);
	~Date();
	int get_month() const;
	int get_day() const;
	int get_year() const;
	int get_hours() const;
	int get_minutes() const;

	void printDate1(int numFutureDays);
	void printDate2(int numFutureDays);
	void printDate3(int numFutureDays);
};
#endif