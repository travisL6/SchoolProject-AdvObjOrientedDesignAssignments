#include <iostream>
#include <string>
#include "Date.h"
#include <cassert>
using namespace std;

int main()
{
	int month;
	int day;
	int year;
	int hours;
	int minutes;
	cout << "Hello, please enter the date down below" << endl;

    cout << "Month: ";
	cin >> month;

	cout << endl << "Day: ";
	cin >> day;

	cout << endl << "Year: ";
	cin >> year;

	cout << endl << "Hours: ";
	cin >> hours;

	cout << endl << "Minutes: ";
	cin >> minutes;

	Date d(month, day, year, hours, minutes);

	cout << endl << "Here is the date you entered: ";
	d.printDate1(0);
	int futureDays;
	cout << endl << "Now enter the amount of days to add to the date: ";
	cin >> futureDays;
	cout << "Future dates: " << endl;
	d.printDate1(futureDays);
	d.printDate2(futureDays);
	d.printDate3(futureDays);
}
