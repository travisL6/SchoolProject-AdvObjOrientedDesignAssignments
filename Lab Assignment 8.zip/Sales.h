#include <fstream>
#include <string>
#include <iostream>
using namespace std;
#ifndef Sales_H
#define Sales_H

class Sales
{
private:
	int numOfSales;
	const char* inputFileName;
	ifstream inputFile;
	class Item{
		public:
			int itemID;
			int numSold;
			double deviation;
			double price;
			double total;
	};
	Item* items;
	double average;
	double stdDeviation;
	void getInput();
	void setDeviation();
	void setAverage();
	void printResult() const;

public:
	Sales(int numSales, const char* inputFileName);
	~Sales();
};
#endif