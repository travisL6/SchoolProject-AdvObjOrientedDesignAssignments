#include "Sales.h"
#include <iomanip>
#include <cmath>

Sales::Sales(int numSales, const char* ifname) : numOfSales(numSales), inputFileName(ifname) {

	inputFile.open(inputFileName);
	items = new Item[numOfSales];
	getInput();
	setAverage();
	setDeviation();
	printResult();
}

Sales:: ~Sales()
{
	delete[] items;
	inputFile.close();
}

void Sales::getInput()
{
	for (int i = 0; i < numOfSales; i++)
	{
		inputFile >> items[i].itemID;
		inputFile >> items[i].price;
		inputFile >> items[i].numSold;
	}
}

void Sales::setAverage()
{
	double totalItemsSold = 0;
	for (int i = 0; i < numOfSales; i++)
	{
		int check_id = items[i].itemID;
		for (int i = 0; i < numOfSales; i++)
		{
			if (items[i].itemID == check_id)
			{
				items[i].total = items[i].price * items[i].numSold;
				totalItemsSold += items[i].numSold;
			}
		}
	}
	average = totalItemsSold / 12;
}

void Sales::setDeviation()
{
	double standardDev = 0;
	for (int i = 0; i < numOfSales; i++)
	{
		standardDev += pow(items[i].numSold - average, 2); 
	}
	stdDeviation = sqrt(standardDev / 12);
}

void Sales::printResult() const
{
	cout << endl;
	cout << "Id	    Price      NumSold			 Total" << endl;
	cout << "---	    -----      ------		       ---------" << endl;

	for (int i = 0; i < numOfSales; i++)
	{
		cout << setw(4) << noshowpoint << noshowpos;
		cout << right << items[i].itemID;
		cout << setw(14) << noshowpoint << noshowpos;
		cout << right << items[i].price;
		cout << setw(10) << right << items[i].numSold;
		cout << fixed << setw(20) << right << setprecision(2);
		cout << showpoint;
		cout << "$" << items[i].total << endl;
	}
	cout << "Average Number of Sales: " << fixed << setw(4);
	cout << setprecision(2) << average << endl;
	cout << "Standard Deviation of Number of Sales: " << stdDeviation;
}