#include <iostream>
#include "Sales.h"

int main()
{
    Sales s(12, "items.txt");
}


