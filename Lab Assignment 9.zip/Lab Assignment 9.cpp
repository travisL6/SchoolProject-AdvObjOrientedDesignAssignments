#include <iostream>
#include <string>
using namespace std;


string intToHexadecimal(int x)
{
    //empty string to hold the converted number
    string hex = "";
    char hexValues[] = { '0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F' };
    while (x != 0)
    {
        int remainder = 0;
        string character;
        remainder = x % 16;

        character = hexValues[remainder];
        hex = character + hex;
        
        x = x / 16;
    }
    return hex;
}


int main()
{
    int num;
    cout << "Enter a number to convert to hexadecimal: ";
    cin >> num;
    string numHex = intToHexadecimal(num);
    cout << "Hexadecimal: " << numHex;

    return 0;
}


