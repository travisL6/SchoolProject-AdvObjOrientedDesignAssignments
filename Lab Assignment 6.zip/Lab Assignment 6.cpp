#include <iostream>
#include<chrono>
#include<ctime>
using namespace std;
using namespace std::chrono;

void createOriginal(int array[]);
void printArray(int array[]);
void printAscending(int array[]);
void printAscendingRef(int* array);

int main()
{
    srand(time(0));

    int donations[10000] = {};

    cout << "The donations in original order:" << endl;
    auto start = high_resolution_clock::now();
    createOriginal(donations);
    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<microseconds>(stop - start);

    printArray(donations);
    cout << endl << "Time in microsecond in createOriginal: " << duration.count() << "ms" << endl;


    cout << endl << "The donations in ascending order:" << endl;
    auto start1 = high_resolution_clock::now();
    printAscending(donations);
    auto stop1 = high_resolution_clock::now();
    auto duration1 = duration_cast<microseconds>(stop1 - start1);
    cout << endl << "Time in microsecond in printAscending: " << duration1.count() << "ms" << endl;

    cout << endl << "The donations in ascending order by reference/pointer:" << endl;
    auto start2 = high_resolution_clock::now();
    printAscendingRef(donations);  
    auto stop2 = high_resolution_clock::now();
    auto duration2 = duration_cast<microseconds>(stop2 - start2);
    cout << endl << "Time in microsecond in printAscendingRef: " << duration2.count() << "ms" << endl;

}


void createOriginal(int array[])
{
    for (int i = 0; i < 10000; i++)
    {
        array[i] = rand() % 100 + 1;
    }
}

//Only print the first 20 elements of the array instead of all 10000 for testing purposes
void printArray(int array[])
{
    for (int i = 0; i < 20; i++)
    {
        cout << array[i] << ' ';
    }
}
//Print the first 20 elements in ascending order. 
void printAscending(int array[])
{
    for (int i = 0; i < 20; i++)
    {
        for (int j = i + 1; j < 20; j++)
        {
            if (array[i] > array[j])
            {
                int temp = array[i];
                array[i] = array[j];
                array[j] = temp;
            }
        }
        cout << array[i] << ' ';
    }
}
void printAscendingRef(int* array)
{
    for (int i = 0; i < 20; i++)
    {
        for (int j = i + 1; j < 20; j++)
        {
            if (array[i] > array[j])
            {
                int temp = array[i];
                array[i] = array[j];
                array[i] = temp;
            }
        }
        cout << array[i] << ' ';
    }
}