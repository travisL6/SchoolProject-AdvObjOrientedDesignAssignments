#ifndef ProductionWorker_H
#define ProductionWorker_H
#include "Employee.h"
#include <string>
class ProductionWorker : public Employee
{
private:
	int shift;
	double payRate;
public:
	ProductionWorker();
	ProductionWorker(string name, int num, Date hireDate, int typeShift, double pay);
	~ProductionWorker();
	int getShift() const;
	double getPayRate() const;

	void setShift(int shift);
	void setPayRate(double payRate);
};
#endif
