#ifndef TeamManager_H
#define TeamManager_H
#include "ProductionWorker.h"
#include <string>
class TeamManager : public ProductionWorker
{
private:
	double monthlyBonus;
	int trainingHoursRequired;
	int trainingHoursAttended;
public:
	TeamManager();
	TeamManager(string name, int num, Date hireDate, int shift, double payRate, double monthlyBonus, int hoursRequired, int hoursAttended);
	~TeamManager();
	double getBonus() const;
	int getHoursRequired() const;
	int getHoursAttended() const;

	void setBonus(double bonus);
	void setHoursRequired(int hours);
	void setHoursAttended(int hours);
};
#endif
