#include <iostream>
#include "TeamManager.h"
#include <cassert>
using namespace std;

TeamManager::TeamManager() 
{
	monthlyBonus = 0;
	trainingHoursRequired = 30;
	trainingHoursAttended = 0;
}

TeamManager::TeamManager(string name, int num, Date hireDate, int shift, double payRate, double monthlyBonus, int hoursRequired, int hoursAttended) : ProductionWorker(name, num, hireDate, shift, payRate)
{
	if (monthlyBonus < 0)
	{
		cout << "Monthly bonus cannot be negative.";
		assert(false);
	}
	if (hoursRequired < 0)
	{
		cout << "Hours required cannot be negative.";
		assert(false);
	}
	if (hoursAttended < 0)
	{
		cout << "Hours attended cannot be negative.";
		assert(false);
	}

	this->monthlyBonus = monthlyBonus;
	this->trainingHoursRequired = hoursRequired;
	this->trainingHoursAttended = hoursAttended;
}

TeamManager::~TeamManager(){}

double TeamManager::getBonus() const
{
	return this->monthlyBonus;
}

int TeamManager::getHoursRequired() const
{
	return this->trainingHoursRequired;
}

int TeamManager::getHoursAttended() const
{
	return this->trainingHoursAttended;
}

void TeamManager::setBonus(double bonus)
{
	while (bonus < 0)
	{
		cout << "Bonus cannot be negative, please enter again";
		cin >> bonus;
	}
	monthlyBonus = bonus;
}

void TeamManager::setHoursRequired(int hours)
{
	while (hours < 0)
	{
		cout << "Hours cannot be negative, please enter again";
		cin >> hours;
	}
	trainingHoursRequired = hours;
}

void TeamManager::setHoursAttended(int hours)
{
	while (hours < 0)
	{
		cout << "Hours cannot be negative, please enter again";
		cin >> hours;
	}
	trainingHoursAttended = hours;
}