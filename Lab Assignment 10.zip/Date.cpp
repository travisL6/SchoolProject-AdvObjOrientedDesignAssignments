#include <iostream>
#include "Date.h"
#include <cassert>
using namespace std;

string monthName[] = { "January", "February", "March",
		"April", "May", "June", "July",
		"August", "September", "October",
		"November", "December" };

Date::Date()
{
	this->month = 1;
	this->day = 1;
	this->year = 2021;
}

Date::Date(int month, int day, int year)
{
	if (month > 12 || month < 1)
	{
		cout << "The month is invalid.";
		assert(false);
	}
	else this->month = month;

	if (day > 31 || day < 1)
	{
		cout << "The day is invalid.";
		assert(false);
	}
	else this->day = day;

	this->year = year;
}

Date:: ~Date()
{
}

int Date::get_month() const
{
	return this->month;
}

int Date::get_day() const
{
	return this->day;
}

int Date::get_year() const
{
	return this->year;
}

void Date::printDate()
{
	cout << this->get_month() << "/" << this->get_day() << "/" << this->get_year() << " " << endl;
}