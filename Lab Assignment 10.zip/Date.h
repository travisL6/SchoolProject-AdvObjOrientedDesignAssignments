#ifndef Date_H
#define Date_H
class Date
{
private:
	int month;
	int day;
	int year;
public:
	Date();
	Date(int month, int day, int year);
	~Date();
	int get_month() const;
	int get_day() const;
	int get_year() const;


	void printDate();
};
#endif
