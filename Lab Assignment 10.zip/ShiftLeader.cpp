#include <iostream>
#include "ShiftLeader.h"
#include <cassert>
using namespace std;

ShiftLeader::ShiftLeader() 
{
	annualSalary = 0;
	annualBonus = 0;
}

ShiftLeader::ShiftLeader(string name, int num, Date hireDate, double salary, double bonus) : Employee(name, num, hireDate), annualSalary(salary), annualBonus(bonus)
{
}

ShiftLeader::~ShiftLeader() {}

double ShiftLeader::getSalary() const
{
	return this->annualSalary;
}

double ShiftLeader::getBonus() const
{
	return this->annualBonus;
}

void ShiftLeader::setBonus(double bonus)
{
	while (bonus < 0)
	{
		cout << "Bonus cannot be negative, please enter again";
		cin >> bonus;
	}
	annualBonus = bonus;
}