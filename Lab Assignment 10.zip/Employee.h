#ifndef Employee_H
#define Employee_H
#include <fstream>
#include <iostream>
#include <string>
#include "Date.h"
using namespace std;
class Employee
{
private:
	string employeeName;
	int employeeNumber;
	Date hireDate;
public:
	Employee();
	Employee(string name, int num, Date date);
	~Employee();

	//getters
	string getEmployeeName() const;
	int getEmployeeNumber() const;
	Date getHireDate() const;
	void print() const;
};
#endif