#ifndef ShiftLeader_H
#define ShiftLeader_H
#include "Employee.h"
class ShiftLeader : public Employee
{
private:
	double annualSalary;
	double annualBonus;
public:
	ShiftLeader();
	ShiftLeader(string name, int num, Date hireDate, double salary, double bonus);
	~ShiftLeader();
	double getSalary() const;
	double getBonus() const;
	void setBonus(double bonus);
};
#endif
