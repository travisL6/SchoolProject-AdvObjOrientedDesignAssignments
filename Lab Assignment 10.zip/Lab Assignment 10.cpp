#include <iostream>
#include "Date.h"
#include "Employee.h"
#include "ProductionWorker.h"
#include "ShiftLeader.h"
#include "TeamManager.h"

using namespace std;
int main()
{
    Date d1(11, 18, 2003);
    Date d2(3, 2, 2013);
    Date d3(6, 26, 2000);
    ProductionWorker prodWorker("Jeff", 3, d1, 1, 23.15);

    cout << "Data for Production Worker Object: " << endl;
    cout << "Name: " << prodWorker.getEmployeeName() << endl;
    cout << "Employee Number: " << prodWorker.getEmployeeNumber() << endl;
    cout << "Hire Date: "; prodWorker.getHireDate().printDate();
    cout << "Shift: " << prodWorker.getShift() << endl;
    cout << "Pay Rate: $" << prodWorker.getPayRate() << endl;

    ShiftLeader shiftLeader("Ted", 2, d2, 61525.50, 5000);

    cout << endl << "Data for Shift Leader Object: " << endl;
    cout << "Name: " << shiftLeader.getEmployeeName() << endl;
    cout << "Employee Number: " << shiftLeader.getEmployeeNumber() << endl;
    cout << "Hire Date: "; shiftLeader.getHireDate().printDate();
    cout << "Salary: $" << shiftLeader.getSalary() << endl;
    cout << "Annual Bonus: $" << shiftLeader.getBonus() << endl;

    TeamManager teamManager("Joseph", 1, d3, 2, 34.50, 500.75, 35, 22);

    cout << endl << "Data for Team Manager Object: " << endl;
    cout << "Name: " << teamManager.getEmployeeName() << endl;
    cout << "Employee Number: " << teamManager.getEmployeeNumber() << endl;
    cout << "Hire Date: "; teamManager.getHireDate().printDate();
    cout << "Shift: " << teamManager.getShift() << endl;
    cout << "Pay Rate: $" << teamManager.getPayRate() << endl;
    cout << "Monthly Bonus: $" << teamManager.getBonus() << endl;
    cout << "Hours Required: " << teamManager.getHoursRequired() << endl;
    cout << "Hours Attended: " << teamManager.getHoursAttended() << endl;
}


