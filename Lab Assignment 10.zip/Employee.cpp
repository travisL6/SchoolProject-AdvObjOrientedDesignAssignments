#include "Employee.H"
#include "Date.h"
#include <iomanip>
using namespace std;

Employee::Employee()
{

}

Employee::Employee(string name, int num, Date hire) : employeeName(name), employeeNumber(num), hireDate(hire) {}

Employee::~Employee() {}

string Employee::getEmployeeName() const
{
	return this->employeeName;
}

int Employee::getEmployeeNumber() const
{
	return this->employeeNumber;
}

Date Employee::getHireDate() const
{
	return this->hireDate;
}

void Employee::print() const
{
	cout << "\nName: " << getEmployeeName();
	cout << "\nEmployee Number: " << getEmployeeNumber();
	cout << "\nHire date: ";
	getHireDate().printDate();
}