#include <iostream>
#include "ProductionWorker.h"
#include <cassert>
using namespace std;

ProductionWorker::ProductionWorker() 
{
	shift = 1;
	payRate = 0;
}

ProductionWorker::ProductionWorker(string name, int num, Date hireDate, int typeShift, double pay) : Employee(name, num, hireDate)
{
	if (typeShift != 1 && typeShift != 2)
	{
		cout << "The value for the shift is incorrect, please try again";
		assert(false);
	}
	shift = typeShift;
	if (pay < 0)
	{
		cout << "The value for the pay rate cannot be negative, please try again";
		assert(false);
	}
	payRate = pay;
}

ProductionWorker::~ProductionWorker(){}

int ProductionWorker::getShift() const
{
	return this->shift;
}

double ProductionWorker::getPayRate() const
{
	return this->payRate;
}

void ProductionWorker::setShift(int shift)
{
	if (shift != 1 && shift != 2)
	{
		cout << "The value for the shift is incorrect, please try again";
		assert(false);
	}
	else {
		this->shift = shift;
	}
}

void ProductionWorker::setPayRate(double payRate)
{
	if (payRate < 0)
	{
		cout << "The value for the pay rate cannot be negative, please try again";
		assert(false);
	}
	else {
		this->payRate = payRate;
	}
}