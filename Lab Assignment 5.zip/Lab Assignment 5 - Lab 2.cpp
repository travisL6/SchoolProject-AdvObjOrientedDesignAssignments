#include <iostream>
#include <iomanip>
using namespace std;

double& findLowestFraction(double& x, double& y, double& z)
{
	double min = x;

	if (y < min) 
	{
		min = y;
	}
	if (z < min)
	{
		min = z;
	}
	return min;
}

int main()
{
	double x = (double) 1 / 4;
	double y = (double) 20 / 73;
	double z = (double) 13 / 23;
	cout << setprecision(2);
	cout << "The three fractions are: " << endl << x << endl << y  << endl << z << endl;
	
	double answer = findLowestFraction(x, y, z);
	cout << "The lowest fraction is: " << answer;
}
