#include <iostream>
using namespace std;

void print(int(*arr)[3])
{
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			arr[i][j] = (arr[i][j] * 2);
			cout << arr[i][j] << ' ';
		}
		cout << endl;
	}
}

int main()
{
	int array[3][3] =	{
						{10, 20, 30},
						{40, 50, 60},
						{70, 80, 90}
						};

	print(array);
}
