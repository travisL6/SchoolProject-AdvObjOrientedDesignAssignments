#include <iostream>
#include <string>
using namespace std;

// Declarations of reverseDigits and isPalindrome functions
int reverseDigits(int num);
bool isPalindrome(int num);

int main()
{
    // Declaration of a variable
    int num;
    // Inputting and validating an integer
    do
    {
        cout << "Enter a positive integral number: ";
        cin >> num;
    } while (num < 0);
    // Printing the result of being a palindrome        
    cout << "The number " << num;
    if (isPalindrome(num))
    {
        cout << " is a palindrome.";
    }

    else
    {
        cout << " is not a palindrome.";
    }
    return 0;
}

// Definition of reverseDigits function (NEED TO COMPLETE)
int reverseDigits(int num)
{
    string reversed = to_string(num);
    reverse(reversed.begin(), reversed.end());
    int completedReversal = stoi(reversed);
    return completedReversal;
}

// Definition of isPalindrome function
bool isPalindrome(int num)
{
    int reversed = reverseDigits(num);
    return (reversed == num);
}