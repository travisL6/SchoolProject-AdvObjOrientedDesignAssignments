#include <iostream>
#include <cstdlib>
#include <vector>
using namespace std;

void makeOriginal(int arr[][6], int size);
void makeLeftToRight(int arr[][6], int arr1[], int size);
void makeRightToLeft(int arr[][6], int arr2[], int size);
void printTwoDimensional(int arr[][6], int size);
void printOneDimensional(int arr[], int size);

int random;
const int SIZE = 6;

int main()
{
    int twoDimArray[6][6];
    int oneDimArray[36];
    cout << "Original Two Dimensional Array: " << endl;
    makeOriginal(twoDimArray, SIZE);
    printTwoDimensional(twoDimArray, SIZE);

    cout << endl;

    cout << "Left to Right Diagonal One Dimensional Array: " << endl;
    makeLeftToRight(twoDimArray, oneDimArray, SIZE);
    printOneDimensional(oneDimArray, SIZE);

    cout << endl << endl;

    cout << "Right to Left Diagonal One Dimensional Array: " << endl;
    makeRightToLeft(twoDimArray, oneDimArray, SIZE);
    printOneDimensional(oneDimArray, SIZE);

}


void makeOriginal(int arr[][6], int size)
{
    srand(time(0));
    for (int i = 0; i < size; i++) {

        for (int j = 0; j < size; j++) {
            arr[i][j] = rand() % (199 + 1 - 100) + 100;
        }
    }
}

void printTwoDimensional(int arr[][6], int size)
{
    for (int i = 0; i < size; i++) {

        for (int j = 0; j < size; j++) {
            cout << arr[i][j] << ' ';
        }
        cout << endl;
    }
}

void makeLeftToRight(int arr[][6], int arr1[], int size)
{
    for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < size; j++)
        {
            arr1[i * size + j] = arr[i][j];
        }
    }
}

void makeRightToLeft(int arr[][6], int arr2[], int size)
{
    int w = 0;
    int v = 0;
    for (int i = size - 1; i >= 0; i--)
    {
        for (int j = size - 1; j >= 0; j--)
        {
            arr2[w * size + v] = arr[i][j];
            v++;
        }
        w++;
        v = 0;
    }
}

void printOneDimensional(int arr[], int size)
{
    for (int x = 0; x < size; x++) {
        cout << arr[x * size + x] << ' ';
    }
}