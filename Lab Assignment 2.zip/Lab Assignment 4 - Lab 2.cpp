// Lab Assignment 3.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
    int type;
    int size;
    bool check1 = false; 
    bool check2 = false;

    do
    {
        cout << "Enter the type of pattern (1-4): ";
        cin >> type;
        if (type >= 1 && type <= 4) {
            break;
        }
        else {
           cout << "Invalid type, try again." << endl;
        }
        
    } while (type < 1 || type > 4);

    do
    {
        cout << "Enter the size of pattern (1-9): ";
        cin >> size;
        if (size >= 1 && size <= 9) {
            break;
        }
        else {
            cout << "Invalid size, try again." << endl;
        }
        
    } while (size < 1 || size > 9);

    switch (type) {
    case 1: 
        for (int i = 1; i <= size; i++) { //type 1
            for (int x = 1; x <= i; x++) {
                cout << "*";
            }
            cout << endl;
        }
          break;
    case 2: 
        for (int i = 1; i <= size; i++) { //type 2
            for (int x = size - i; x >= 0; x--) {
                cout << "*";
            }
            cout << endl;
        }
          break;
    case 3: 
        for (int i = 1; i <= size; i++) { //type 3
            for (int x = 1; x < i; x++) {
                cout << " ";
            }
            for (int x = size - i; x >= 0; x--) {
                cout << "*";
            }
            cout << endl;
        }
          break;
    case 4: 
        for (int i = 1; i <= size; i++) { //type 4
            for (int x = size - i; x > 0; x--) {
            cout << " ";
            }
            for (int x = 1; x <= i; x++) {
            cout << "*";
            }
            cout << endl;
        }
          break;
    }

}


