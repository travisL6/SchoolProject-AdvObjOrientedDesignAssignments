// Lab Assignment 3.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
    int month;
    int day;
    int year;
    cout << "Enter the month: ";
    cin >> month;
    cout << "Enter the day of the month: ";
    cin >> day;
    cout << "Enter the year: ";
    cin >> year;

    if (month == 1) {
        month = 13;
        year--;
    }
    if (month == 2) {
        month = 14;
        year--;
    }

    int weekday = (day + 26 * (month + 1) / 10 + year + year / 4 - year / 100 + year / 400) % 7;

    switch (weekday) {
    case 0:
        cout << month << "/" << day << "/" << year << " is Saturday";
        break;
    case 1:
        cout << month << "/" << day << "/" << year << " is Sunday";
        break;
    case 2:
        cout << month << "/" << day << "/" << year << " is Monday";
        break;
    case 3:
        cout << month << "/" << day << "/" << year << " is Tuesday";
        break;
    case 4:
        cout << month << "/" << day << "/" << year << " is Wednesday";
        break;
    case 5:
        cout << month << "/" << day << "/" << year << " is Thursday";
        break;
    case 6:
        cout << month << "/" << day << "/" << year << " is Friday";
        break;
    }
    return 0;
}


