// Lab Assignment 3.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
    const float LIMIT1 = 30000.00;
    const float LIMIT2 = 80000.00;
    const float LIMIT3 = 120000.00;
    const float RATE1 = .03;
    const float RATE2 = .12;
    const float RATE3 = .18;
    const float RATE4 = .30;
    float income;
    float tax;
    cout << "Enter income in dollars: ";
    cin >> income;

    if (income <= LIMIT1 && income >= 0) {
        tax = income * RATE1;
        cout << "Tax due: $" << tax;
    }
    else if (income <= LIMIT2)
    {
        tax = (income - LIMIT1) * RATE2;
        tax += LIMIT1 * RATE1;
        cout << "Tax due: $" << tax;
    }
    else if (income <= LIMIT3) {
        tax = (income - LIMIT2) * RATE3;
        tax += LIMIT2 * RATE2;
        tax += LIMIT1 * RATE1;
        cout << "Tax due: $" << tax;
    }
    else if (income > LIMIT3) {
        tax = (income - LIMIT3) * RATE4;
        tax += LIMIT3 * RATE3;
        tax += LIMIT2 * RATE2;
        tax += LIMIT1 * RATE1;
        cout << "Tax due: $" << tax;
    }
    else {
        cout << "Error! Invalid income entered. Please try again.";
    }
    return 0;
}

